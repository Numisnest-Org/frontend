import { Paper } from '@mui/material'
import React from 'react'

const Barchart = () => {
  return (
    <Paper sx={{ml:"2rem"}}>

    </Paper>
  )
}

export default Barchart